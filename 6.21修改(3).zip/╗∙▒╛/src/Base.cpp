#include "Base.h"

Base::Base() {

}


string Base::toString() {
	return id + "," + name + ",";
}

Base::~Base() {
}